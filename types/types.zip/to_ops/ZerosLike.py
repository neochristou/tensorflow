# ZerosLikeOp

import tensorflow as tf

x = tf.constant(4.22802925, shape=[4,9], dtype=tf.float32)
tf.raw_ops.ZerosLike(x=x)
