# WriteFileOp

import tensorflow as tf

filename = tf.constant("[]", shape=[], dtype=tf.string)
tf.raw_ops.WriteFile(filename=filename)
