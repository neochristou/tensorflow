# EncodeJpegVariableQualityOp

import tensorflow as tf

images = tf.constant(80, shape=[], dtype=tf.int32)
tf.raw_ops.EncodeJpegVariableQuality(images=images)
