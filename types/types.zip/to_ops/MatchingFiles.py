# MatchingFilesOp

import tensorflow as tf

pattern = tf.constant("/tmp/io_ops_test81p5mf4e/tmpytx_gdwy/ABcDEF.GHrb77awbs", shape=[], dtype=tf.string)
tf.raw_ops.MatchingFiles(pattern=pattern)
