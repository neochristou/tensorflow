# DecodeBase64Op

import tensorflow as tf

input = tf.constant("faCyWktIzZzb3f_hqujPPGovJyD1TMTAN6KRKExkKOk4dctFN_frYjXmk93ha8Ov9_JI6SA3AG136y7fT49L6qBxzAjRyhdtn76dhc223O7itOzHkqZPD5RNddCq1MXuNQoEa", shape=[], dtype=tf.string)
tf.raw_ops.DecodeBase64(input=input)
