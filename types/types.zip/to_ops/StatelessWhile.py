# WhileOp

import tensorflow as tf

cond = while_1_cond_2109[]
body = while_1_body_2110[]
output_shapes = [[], [], []]
parallel_iterations = 10
input = tf.constant(0, shape=[], dtype=tf.int32)
tf.raw_ops.StatelessWhile(input=input, cond=cond, body=body, output_shapes=output_shapes, parallel_iterations=parallel_iterations)
