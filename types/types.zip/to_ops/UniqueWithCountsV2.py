# UniqueOp

import tensorflow as tf

out_idx = DT_INT32
x = tf.constant(-1, shape=[3], dtype=tf.float32)
tf.raw_ops.UniqueWithCountsV2(x=x, axis=axis)
