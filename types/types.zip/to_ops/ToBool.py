# ToBoolOp

import tensorflow as tf

input = tf.constant(0, shape=[], dtype=tf.int32)
tf.raw_ops.ToBool(input=input)
