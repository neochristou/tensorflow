# ReadFileOp

import tensorflow as tf

filename = tf.constant("/tmp/io_ops_test81p5mf4e/tmpz3c3vnee/ReadFileTestfnr9ugnn", shape=[], dtype=tf.string)
tf.raw_ops.ReadFile(filename=filename)
