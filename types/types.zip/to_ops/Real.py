# UnaryOp

import tensorflow as tf

input = tf.constant(1229312, shape=[], dtype=tf.float32)
tf.raw_ops.Real(input=input)
