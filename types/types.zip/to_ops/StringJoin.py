# StringJoinOp

import tensorflow as tf

separator = ""
inputs = tf.constant("/tmp/extension_type_teste8qs34a3mb8f30j4/variables/variables", shape=[], dtype=tf.string)
tf.raw_ops.StringJoin(inputs=inputs, separator=separator)
